//
//  AppViewController.m
//  TetrisClassic
//
//  Created by Earth on 2020/9/24.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "AppViewController.h"

#define URL_LOCAL_INDEX  @"tetris/index.html"
#define URL_NETWORK_INDEX  @"https://binaryify.github.io/vue-tetris/?lan=zh"

static const NSInteger kGoogleAdsLength = 1200; // 20min显示一次

@interface AppViewController () <WKUIDelegate, WKNavigationDelegate, GADInterstitialDelegate>
@property(nonatomic, copy) NSString *htmlUrlString;
@property(nonatomic, assign) BOOL isLocalHTMLString;
@property(nonatomic, assign) BOOL isLoadSuccessOnce;
@property(nonatomic, strong) WKWebView *webView;
@property(nonatomic, strong) WKWebViewConfiguration *config;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, assign) NSInteger timeLeft;
@property(nonatomic, assign) BOOL adUnitIDFirstLoad;
@property(nonatomic, strong) GADInterstitial *interstitial;
@property(nonatomic, strong) NSArray<NSString *> *adUnitIDArray;
@property(nonatomic, strong) DGActivityIndicatorView *activityView;
@end

@implementation AppViewController

- (BOOL)shouldAutorotate {
    return NO;
}

- (BOOL)prefersStatusBarHidden {
    return NO;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        _adUnitIDFirstLoad = YES;
        _isLoadSuccessOnce = NO;
        [self settingIsLocalHTMLString:NO];
    }
    return self;
}

- (void)settingIsLocalHTMLString:(BOOL)isLocalHTMLString
{
    self.isLocalHTMLString = isLocalHTMLString;
    if (_isLocalHTMLString) {
        self.htmlUrlString = URL_LOCAL_INDEX;
    } else {
        self.htmlUrlString = URL_NETWORK_INDEX;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[self colorWithHexString:(@"#159588")]];
    Reachability* reach = [Reachability reachabilityWithHostname:@"www.baidu.com"];
    reach.reachableBlock = ^(Reachability*reach) {
        if (!self.isLoadSuccessOnce) {
            [self settingIsLocalHTMLString:NO];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self viewDidLoadNetworkReach];
            });
        }
    };
    reach.unreachableBlock = ^(Reachability*reach) {
        if (!self.isLoadSuccessOnce) {
            [self settingIsLocalHTMLString:YES];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self viewDidLoadNetworkUnReach];
            });
        }
    };
    [reach startNotifier];
}

- (void)viewDidLoadNetworkReach
{
    [self setActivityStartAnimating];
    
    [self startNewGoogleAds];
    
    [self startLoadRequestWebHtml];
}

- (void)viewDidLoadNetworkUnReach
{
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
    }
    self.adUnitIDFirstLoad = NO;
    [self startLoadRequestWebHtml];
}

#pragma mark - Google Ads logic

- (void)startNewGoogleAds
{
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
    }
    [self createAndLoadInterstitial];
    self.timeLeft = kGoogleAdsLength;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0f
                                                  target:self
                                                selector:@selector(decrementTimeLeft:)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void)createAndLoadInterstitial
{
#if TARGET_IPHONE_SIMULATOR
    self.interstitial = [[GADInterstitial alloc] initWithAdUnitID:@"ca-app-pub-3940256099942544/4411468910"];
    [self.interstitial setDelegate:self];
    [self.interstitial loadRequest:[GADRequest request]];
#else
    NSMutableArray<NSString *> *randomMutableArray = [NSMutableArray arrayWithArray:self.adUnitIDArray];
    if ([randomMutableArray count] > 1) {
        for (NSUInteger i = [randomMutableArray count] - 1; i > 0; --i) {
            [randomMutableArray exchangeObjectAtIndex:i withObjectAtIndex:arc4random_uniform((int32_t)(i + 1))];
        }
    }
    NSString *adUnitIdentifier = [randomMutableArray firstObject];
    if (adUnitIdentifier.length > 0) {
        self.interstitial = [[GADInterstitial alloc] initWithAdUnitID:adUnitIdentifier];
        [self.interstitial setDelegate:self];
        [self.interstitial loadRequest:[GADRequest request]];
    }
#endif
}

- (void)presentToShowGoogleAds
{
    [self.timer invalidate];
    self.timer = nil;
    if (self.interstitial.isReady) {
        [self.interstitial presentFromRootViewController:self];
    } else {
        [self startNewGoogleAds];
    }
}

- (void)decrementTimeLeft:(NSTimer *)timer
{
    self.timeLeft --;
    NSLog(@"时间 => %ld", self.timeLeft);
    if (self.timeLeft <= 0) {
        [self presentToShowGoogleAds];
    }
}

- (void)interstitialDidReceiveAd:(GADInterstitial *)ad {
    if (self.activityView.animating) {
        [self setActivityStopAnimating];
    }
    if (self.adUnitIDFirstLoad) {
        self.timeLeft = 0;
        self.adUnitIDFirstLoad = NO;
    }
}

- (void)interstitial:(GADInterstitial *)ad didFailToReceiveAdWithError:(GADRequestError *)error {
    if (self.activityView.animating) {
        [self setActivityStopAnimating];
    }
    if (self.adUnitIDFirstLoad) {
        self.adUnitIDFirstLoad = NO;
        [self performSelector:@selector(showWebView) withObject:self afterDelay:0.0f];
    }
}

- (void)interstitialWillPresentScreen:(nonnull GADInterstitial *)ad
{
    [self performSelector:@selector(showWebView) withObject:self afterDelay:1.5f];
}

- (void)interstitialDidDismissScreen:(GADInterstitial *)interstitial {
    [self startNewGoogleAds];
}


#pragma mark - StartLoadRequestWebHtml

- (void)startLoadRequestWebHtml
{
    if (_isLocalHTMLString && ![self.htmlUrlString containsString:@"https"]) {
        NSString *urlString = [NSString stringWithFormat:@"%@", self.htmlUrlString];
        NSURL *baseURL = [NSURL URLWithString:urlString relativeToURL:[[NSBundle mainBundle] bundleURL]];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:baseURL];
        [request setTimeoutInterval:30.0f];
        [self.webView loadRequest:request];
    } else {
        NSString *urlString = self.htmlUrlString;
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
        [request setTimeoutInterval:30.0f];
        [self.webView loadRequest:request];
    }
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    self.webView.hidden = YES;
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    if (!webView.isLoading) {
        self.isLoadSuccessOnce = YES;
    }
    [self performSelector:@selector(showWebView) withObject:self afterDelay:0.0f];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    [self performSelector:@selector(showWebView) withObject:self afterDelay:0.0f];
}

- (void)showWebView
{
    self.webView.hidden = self.adUnitIDFirstLoad;
}


#pragma mark - WKUIDelegate

- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:nil message:message ? : @"" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * action = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }];
    [alertController addAction:action];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:message ? : @"" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction * cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(NO);
    }];
    
    UIAlertAction * confirmAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:confirmAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler {
    
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:prompt message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.text = defaultText;
    }];
    UIAlertAction * action = [UIAlertAction actionWithTitle:@"完成" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(alertController.textFields[0].text ? : @"");
    }];
    [alertController addAction:action];
    
    [self presentViewController:alertController animated:YES completion:nil];
}


#pragma mark - Getter/Setter

- (WKWebView *)webView
{
    if (!_webView) {
        _webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:self.config];
        _webView.navigationDelegate = self;
        _webView.UIDelegate = self;
        _webView.allowsBackForwardNavigationGestures = NO; // 是否允许手势，后退前进等操作
        _webView.scrollView.bounces = YES; // 是否允许拖动效果
        _webView.hidden = YES;
        [self.view addSubview:_webView];
    }
    return _webView;
}

- (WKWebViewConfiguration *)config
{
    if (!_config) {
        _config = [[WKWebViewConfiguration alloc] init];
        _config.allowsInlineMediaPlayback = YES;
        // iOS系统版本 >= 9.0
        if (@available(iOS 9.0, *)) {
            _config.allowsPictureInPictureMediaPlayback = YES;
        }
        _config.allowsInlineMediaPlayback = YES;
        _config.allowsAirPlayForMediaPlayback = YES;
        _config.mediaTypesRequiringUserActionForPlayback = WKAudiovisualMediaTypeAll;
    }
    return _config;
}

- (NSArray<NSString *> *)adUnitIDArray
{
    if (!_adUnitIDArray) {
        _adUnitIDArray = @[
            @"ca-app-pub-3574624433847272/3422505610",
            @"ca-app-pub-3574624433847272/1139779592",
            @"ca-app-pub-3574624433847272/5434247824",
            @"ca-app-pub-3574624433847272/5912744062"
        ];
    }
    return _adUnitIDArray;
}

- (DGActivityIndicatorView *)activityView
{
    if (!_activityView) {
        CGFloat activityIndicatorSize = 80.0f;
        _activityView = [[DGActivityIndicatorView alloc]
                         initWithType:DGActivityIndicatorAnimationTypeBallSpinFadeLoader
                         tintColor:[self colorWithHexString:(@"#EECB35")]
                         size:activityIndicatorSize];
        [_activityView setCenter:self.view.center];
        [self.view insertSubview:_activityView atIndex:0];
    }
    return _activityView;
}


#pragma mark - Private

- (void)setActivityStartAnimating
{
    [self.activityView startAnimating];
}

- (void)setActivityStopAnimating
{
    [self.activityView stopAnimating];
    [self.activityView removeFromSuperview];
    [self setActivityView:nil];
}

- (UIColor*)colorWithHexString:(NSString*)stringToConvert
{
    NSString*cString=[[stringToConvert stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    if([cString length]< 6)
        return [UIColor whiteColor];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor whiteColor];
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

@end
