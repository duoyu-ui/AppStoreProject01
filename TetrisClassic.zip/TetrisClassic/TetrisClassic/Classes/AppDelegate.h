//
//  AppDelegate.h
//  TetrisClassic
//
//  Created by Earth on 2020/9/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

